package com.capg.income;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.capg.income.controller")
@ComponentScan("com.capg.income.dao")
@ComponentScan("com.capg.income.service")
@ComponentScan("com.capg.income.model")
@EntityScan(basePackages = {"com.capg.income"})
@SpringBootApplication
public class SpringBootRestDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestDataJpaApplication.class, args);
	}

}
