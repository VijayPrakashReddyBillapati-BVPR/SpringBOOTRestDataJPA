package com.capg.income.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.income.dao.TDSMasterDao;
import com.capg.income.entity.TDSMaster;
@Service
@Transactional
public class TDSMasterServiceImpl implements TDSMasterService {

	@Autowired
	private TDSMasterDao tdsMasterDao;
	@Override
	@Transactional
	public List<TDSMaster> getDetails() {
		
		return tdsMasterDao.getDetails();
	}

	@Override
	@Transactional
	public TDSMaster getDetailsById(int id) {
		// TODO Auto-generated method stub
		return tdsMasterDao.getDetailsById(id);
	}
	
	

}
