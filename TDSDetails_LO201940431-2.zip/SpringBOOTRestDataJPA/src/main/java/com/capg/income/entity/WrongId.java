package com.capg.income.entity;

public class WrongId {

}
