package com.capg.income.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.query.Query;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.capg.income.entity.TDSMaster;


@Repository
@ComponentScan("com.capg.income.*")
public class TDSMasterDaoImpl implements TDSMasterDao {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<TDSMaster> getDetails() {
		Query<TDSMaster> query = (Query<TDSMaster>) entityManager.createQuery("from tds_master ");
		List<TDSMaster> details =  query.getResultList();
		return details;
	}

	@Override
	@Transactional
	public TDSMaster getDetailsById(int id) {
		TDSMaster tdsaster=entityManager.find(TDSMaster.class, id);
		
		return tdsaster;
	}
	

}
