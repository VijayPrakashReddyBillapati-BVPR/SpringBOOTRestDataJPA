package com.capg.income.service;

import java.util.List;

import com.capg.income.entity.TDSMaster;

public interface TDSMasterService {
	public List<TDSMaster> getDetails();
	
	public TDSMaster getDetailsById(int id);
	
}
