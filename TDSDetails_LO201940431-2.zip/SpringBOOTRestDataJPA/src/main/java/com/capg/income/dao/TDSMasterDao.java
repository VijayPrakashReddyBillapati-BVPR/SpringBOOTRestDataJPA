package com.capg.income.dao;

import java.util.List;

import com.capg.income.entity.TDSMaster;

public interface TDSMasterDao {

public List<TDSMaster> getDetails();
	
	public TDSMaster getDetailsById(int id);
	
}
