package com.capg.income.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.income.entity.TDSMaster;
import com.capg.income.service.TDSMasterService;

@RestController
public class TDSMasterController {
	
	@Autowired
	private TDSMasterService tdsMasterService;
	
	@GetMapping("/")
	public String  tdsMasterHome()
	{
		return "WelCome ";
		
	}
	
	@GetMapping("/details")
	public   List<TDSMaster> getDetails(@RequestBody TDSMaster tdsMaster)
	{
		return tdsMasterService.getDetails();
		
		
	}
	@GetMapping("/details/{id}")
	public   TDSMaster getDetailsById(@PathVariable int id)
	{
		
		if(Integer.toString(id)==null)
		{
			throw new RuntimeException("Invalid id "+ id );
		}else {
			return tdsMasterService.getDetailsById(id);
		}
			
		
		
		
	}
	
	
	

}
